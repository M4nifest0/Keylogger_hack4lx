import os

MAINPATH 	= os.path.abspath(os.path.join(os.path.dirname(__file__)))
VERSION 	= '1.0.0'
GITHUB		= 'https://github.com/enddo'
C_GITHUB	= 'https://github.com/TristanCailb'
CODER		= 'Farzin Enddo'
CORRECTOR	= 'Tristan Cailbourdin'
AGENTS 		= list()
