from System import Global

def Banner():
	print (' _______ ')
	print ('< HatKey >')
	print (' ------- ')
	print ('        \   ^__^')
	print ('         \  (xx)\_______')
	print ('            (__)\\       )\\/\\')
	print ('             U  ||----w |') 
	print ('                ||     ||')
	print (' '*10 + '--=' + '[' + 'KeyLogger')
	print (' '*7 + '--+--=' + '[' + 'Version          : ' + Global.VERSION)
	print (' '*7 + '--+--=' + '[' + 'Coder            : ' + Global.CODER)
	print (' '*7 + '--+--=' + '[' + 'Corrector        : ' + Global.CORRECTOR)
	print (' '*7 + '--+--=' + '[' + 'github           : ' + Global.GITHUB)
	print (' '*10 + '--=' + '[' + 'Corrector Github : ' + Global.C_GITHUB)
	print (' \n')